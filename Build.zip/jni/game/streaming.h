#pragma once

class CStreaming
{
public:

    static int AddImageToList(const char * name, bool b);
};
