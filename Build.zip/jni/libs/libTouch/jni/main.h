#pragma once
#include <stdio.h>
#include <string>
extern uintptr_t g_libGTASA;