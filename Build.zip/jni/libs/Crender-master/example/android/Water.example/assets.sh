echo pwd is: $(pwd)

echo copying assets...
cp ../../../media/Water.gles assets
#cp ../../../media/Reflection.gles assets
cp ../../../media/Common.gles assets
