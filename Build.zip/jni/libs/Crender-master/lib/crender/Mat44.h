#ifndef __CRENDER_MAT44_H__
#define __CRENDER_MAT44_H__

#include "Platform.h"

#ifdef __cplusplus
extern "C" {
#endif

struct CrVec3;

struct CrVec4;

typedef struct CrMat44
{
	union
	{
		struct { float
			m00, m01, m02, m03,
			m10, m11, m12, m13,
			m20, m21, m22, m23,
			m30, m31, m32, m33;
		};

		float v[16];
	};

} CrMat44;

CR_API CrMat44 crMat44(
	float m00, float m01, float m02, float m03,
	float m10, float m11, float m12, float m13,
	float m20, float m21, float m22, float m23,
	float m30, float m31, float m32, float m33);

CR_API void crMat44Mult(CrMat44* _out, const CrMat44* a, const CrMat44* b);

CR_API CrBool crMat44Inverse(CrMat44* _out, const CrMat44* m);

CR_API void crMat44Transpose(CrMat44* _out, const CrMat44* m);

CR_API void crMat44Transform(struct CrVec4* _out, const CrMat44* m);

//! assume the plane equation is stored as A, B, C, D
CR_API void crMat44TransformPlane(struct CrVec4* _out, const CrMat44* m);

CR_API void crMat44TransformAffineDir(struct CrVec3* _out, const CrMat44* m);

CR_API void crMat44TransformAffinePt(struct CrVec3* _out, const CrMat44* m);

CR_API void crMat44TransformAffineDirs(struct CrVec3* _out, const struct CrVec3* _in, size_t cnt, const CrMat44* m);

CR_API void crMat44TransformAffinePts(struct CrVec3* _out, const struct CrVec3* _in, size_t cnt, const CrMat44* m);

CR_API void crMat44SetIdentity(CrMat44* _out);

CR_API void crMat44SetTranslation(CrMat44* _out, const struct CrVec3* v);

CR_API void crMat44GetTranslation(struct CrVec3* v, const CrMat44* m);

CR_API void crMat44MakeTranslation(CrMat44* _out, const struct CrVec3* v);

CR_API void crMat44MakeScale(CrMat44* _out, const struct CrVec3* v);

CR_API void crMat44MakeRotationX(CrMat44* _out, float angleInDeg);

CR_API void crMat44MakeRotationY(CrMat44* _out, float angleInDeg);

CR_API void crMat44MakeRotationZ(CrMat44* _out, float angleInDeg);

CR_API void crMat44MakeRotation(CrMat44* _out, const struct CrVec3* axis, float angleInDeg);

CR_API void crMat44GetBasis(struct CrVec3* xaxis, struct CrVec3* yaxis, struct CrVec3* zaxis, const CrMat44* m);

CR_API void crMat44CameraLookAt(CrMat44* _out, const struct CrVec3* eyeAt, const struct CrVec3* lookAt, const struct CrVec3* eyeUp);

CR_API void crMat44Prespective(CrMat44* _out, float fovyDeg, float aspect, float znear, float zfar);

CR_API void crMat44PlanarReflect(CrMat44* _out, const struct CrVec3* normal, const struct CrVec3* point);

//! adjust a projection matrix to match the API's depth range
CR_API void crMat44AdjustToAPIDepthRange(CrMat44* _out);

//! adjust a projection matrix to match the API's projective texture lookup
CR_API void crMat44AdjustToAPIProjectiveTexture(CrMat44* _out);

#ifdef __cplusplus
}
#endif

#endif	// __CRENDER_MAT44_H__