<?php include("db/database.php"); ?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Namphao</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <header>
        <div class="top-bar">
            <a href="free.php">ฟรี</a>
            <h1 class="logo">Namphao</h1>
            <a href="admin/login.php">Admin</a>
        </div>
    </header>
</body>
</html>